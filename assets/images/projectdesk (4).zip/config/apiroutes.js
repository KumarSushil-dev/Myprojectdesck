module.exports={


    userLogin:"/users/login",
    userSignup:"/users/signup",
    userPunchin:"/users/punchin",
    userPunchoout:"/users/punchout",
    dataTransfer:"/users/datatransfer",
    productivityinfo:"/users/productivityinfo",
    breaklist:"/users/breaklist",
    breakstart:"/users/breakstart",
    breakstop:"/users/breakstop",
    activityList:"/users/activeactivity",
    taskList:'/users/tasklist'
    
}