
var host="3.108.65.235/"
var protocols="http://"
var apiVersion="api"

module.exports={

    baseurl:protocols+host+apiVersion,
    datatransfer_url:protocols+host
}