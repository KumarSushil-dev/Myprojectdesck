const apiroutes= require('../config/apiroutes')
const  config= require('../config/config')
const  axios = require('axios')
//import {FormData} from "formdata-node"
var FormData=require('formdata-node')
const fs = require('fs')
const { createReadStream } = require('original-fs')
const { fileFromPath } = require('formdata-node')

       
        module.exports.datatransfer=async (productivityCount,screenshot,totalIdleMinutes,totalKeypressCount,totalMouseMovement,totalClicks,applist,capturetime,productivitytime,token,url=config.baseurl+apiroutes.dataTransfer)=>{
//console.log(url);
//console.log(productivityCount,totalIdleMinutes,totalKeypressCount,totalMouseMovement,totalClicks,applist,capturetime);
//console.log(token);
console.log(applist);
const config = {
  headers: { Authorization: `Bearer ${token}`,
 


}
};

//console.log(body);
//console.log(url);
try {
    var res = await  axios({
      method: 'post',
      url: url,
      headers: { 'Authorization': `Bearer ${token}` },
      data: {
        productivitytime:productivitytime,
  productivityCount:productivityCount,
  screenshot:screenshot,
  totalIdleMinutes:totalIdleMinutes,
  totalKeypressCount:totalKeypressCount,
  totalMouseMovement:totalMouseMovement,
  totalClicks:totalClicks,
  applist:applist,
  capturetime:capturetime
       
        // foo: 'bar', // This is the body part
      }
      
    }
  )
  //console.log(res);
  return  res.data.data

} catch(e){
    console.log(e);
}


};


       
module.exports.productivityinfo=async (token,url=config.baseurl+apiroutes.productivityinfo)=>{
  //console.log(url);
  //console.log(productivityCount,totalIdleMinutes,totalKeypressCount,totalMouseMovement,totalClicks,applist,capturetime);
  //console.log(token);
  
  const config = {
    headers: { Authorization: `Bearer ${token}`,
   
  
  
  }
  };
  
  //console.log(body);
  //console.log(url);
  try {
      var res = await  axios({
        method: 'get',
        url: url,
        headers: { 'Authorization': `Bearer ${token}` }
        
        
      }
    )
    console.log(res.data,"7877979879879");
    //console.log(res);
    return  res.data
  
  } catch(e){
      console.log(e);
  }
  
  
  };


