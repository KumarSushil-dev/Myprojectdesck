const apiroutes= require('../config/apiroutes')
const  config= require('../config/config')
const  axios = require('axios')
module.exports.userLogin= async (emai,password,os,url=config.baseurl+apiroutes.userLogin)=>{
console.log(url);
try {
    var res = await  axios.post(url,{
    email:emai,
    password:password,
    os:os

  })

  return  res

} catch(e){
    console.log(e);
}




}
module.exports.punchIn= async(time,token,url=config.baseurl+apiroutes.userPunchin)=>{
 
  const config = {
    headers: { Authorization: `Bearer ${token}` }
};

  console.log(url);
  try {
      var res = await  axios.post(url,{
        punchInTime:time
  
    },
    
    config
    )
  
    return  res
  
  } catch(e){
      console.log(e);
  }
}
  
  module.exports.punchOut= async(time,worktime,token,url=config.baseurl+apiroutes.userPunchoout)=>{
 
    const config = {
      headers: { Authorization: `Bearer ${token}` }
  };
  
    console.log(url);
    try {
        var res = await  axios.post(url,{
          puchOutTime:time,
          total_work_time:worktime
    
      },
      
      config
      )
    
      return  res
    
    } catch(e){
        console.log(e);
    }
    }

    module.exports.listbreak=async (token,url=config.baseurl+apiroutes.breaklist)=>{
      //console.log(url);
      //console.log(productivityCount,totalIdleMinutes,totalKeypressCount,totalMouseMovement,totalClicks,applist,capturetime);
      //console.log(token);
      
      const config = {
        headers: { Authorization: `Bearer ${token}`,
       
      
      
      }
      };
      
      //console.log(body);
      //console.log(url);
      try {
          var res = await  axios({
            method: 'get',
            url: url,
            headers: { 'Authorization': `Bearer ${token}` }
            
            
          }
        )
        console.log(res.data,"7877979879879");
        //console.log(res);

        if (res.status==200)
        return  res.data
      
      } catch(e){
          console.log(e);
      }
      
      
      };
      module.exports.activityList = async (token,url=config.baseurl+apiroutes.activityList)=>{
        //console.log(url);
        //console.log(productivityCount,totalIdleMinutes,totalKeypressCount,totalMouseMovement,totalClicks,applist,capturetime);
        //console.log(token);
        
        const config = {
          headers: { Authorization: `Bearer ${token}`,
         
        
        
        }
        };
        
        //console.log(body);
        //console.log(url);
        try {
            var res = await  axios({
              method: 'get',
              url: url,
              headers: { 'Authorization': `Bearer ${token}` }
              
              
            }
          )
          console.log(res.data,"");
          //console.log(res);
  
          if (res.status==200)
          return  res.data
        
        } catch(e){
            console.log(e);
        }
        
        
        };

      module.exports.stopBreak= async(type,breakStopTime,token,url=config.baseurl+apiroutes.breakstop)=>{
 
        const configs = {
          headers: { Authorization: `Bearer ${token}` }
      };
      
        console.log(url);
        try {
            var res = await  axios.post(url,{
              breakStopTime:breakStopTime,
              type:type
            },
          
          configs
          )
        
          return  res
        
        } catch(e){
            console.log(e);
        }
        }

        module.exports.startBreak = async(type,breakStartTime,token)=>{
  console.log(config.baseurl+apiroutes.breakstart,"fdffffffffffffffffffffffffffff");
          const configs = {
            headers: { Authorization: `Bearer ${token}` }
        };
        
          
          try {
              var res = await  axios.post(config.baseurl+apiroutes.breakstart,{
                breakStartTime:breakStartTime,
                type:type
              },
            
            configs
            )
         // console.log(res,data);
            if (res.status==200){
            console.log("Sahi ha");
            return  res.data
            } else {
              return null
            }
           
          
          } catch(e){
              console.log(e);
          }
          }





          module.exports.taskList = async (token,url=config.baseurl+apiroutes.taskList)=>{

            
            const config = {
              headers: { Authorization: `Bearer ${token}`,
             
            
            
            }
            };
            
            //console.log(body);
            //console.log(url);
            try {
                var res = await  axios({
                  method: 'get',
                  url: url,
                  headers: { 'Authorization': `Bearer ${token}` }
                  
                  
                }
              )
              console.log(res.data,"");
              //console.log(res);
      
              if (res.status==200)
              return  res.data
            
            } catch(e){
                console.log(e);
            }
            
            
            };