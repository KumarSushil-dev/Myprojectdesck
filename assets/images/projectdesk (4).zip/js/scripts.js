// Example starter JavaScript for disabling form submissions if there are invalid fields
(function () {
  'use strict'

  // Fetch all the forms we want to apply custom Bootstrap validation styles to
  var forms = document.querySelectorAll('.needs-validation')

  // Loop over them and prevent submission
  Array.prototype.slice.call(forms)
    .forEach(function (form) {
      form.addEventListener('submit', function (event) {
        if (!form.checkValidity()) {
          event.preventDefault()
          event.stopPropagation()
        }

        form.classList.add('was-validated')
      }, false)
    })
})()


var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'))
var tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
  return new bootstrap.Tooltip(tooltipTriggerEl)
})






$(document).ready(function(){
  $(".menuToggleBtn").click(function(){
    $(".leftMenuPanel").addClass("open");

  });

  $(".leftMenuPanelClose").click(function(){
    $(".leftMenuPanel").removeClass("open");

  });
});


$(document).ready(function(){
  $(".punchInConfirm").click(function(){
  
    $(".punchInModalBtn").css('display', 'none');
    $(".punchOutModalBtn").css('display', 'block');
 
  });

  $(".punchOutConfirm").click(function(){
  
    $(".punchInModalBtn").css('display', 'block');
    $(".punchOutModalBtn").css('display', 'none');
 
  });

 
});


$(function() {
  $("#chart_graph_newvwndor").highcharts({
      chart: {
          zoomType: 'xy'
      },
      title: {
          text: ""
      },
      // subtitle: {
      //     text: "Source: WorldClimate.com"
      // },
      xAxis: [{
          categories: ['Calling', 'Demo']
      }],
      yAxis: [{ //Primary yAxis
          labels: {
              format: '{value}',
              style: {
                  color: '#89A54E'
              }
          },
          title: {
              text: 'Hourly Duration',
              style: {
                  color: '#3d6db5'
              }
          }
      }, { //Secondary yAxis
          title: {
              text: '',
              style: {
                  color: '#4572A7'
              }
          },
          labels: {
              format: '{value}',
              style: {
                  color: '#4572A7'
              }
          },
          opposite: true
      }],
      tooltip: {
          shared: true
      },
      legend: {
          layout: 'vertical',
          align: 'left',
          x: 1,
          verticalAlign: 'top',
          y: 50,
          floating: true,
          backgroundColor: '#FFFFFF'
      },
      series: [{
          name: '',
          color: '#4775b9',
          type: 'column',
          yAxis: 0,
          data: [1, 2],
          tooltip: {
              valueSuffix: 'H '
          }
        },
      // }, {
      //     name: 'Hour',
      //     color: '#264e88',
      //     type: 'spline',
      //     yAxis: 0,
      //     data: [1, 2, 3, 4, 5, 6, 7, 8, 9],
      //     tooltip: {
      //         valueSuffix: 'H'
      //     }
      // }
    ]}
  );
});




$('textarea').keyup(function() {
    
  var characterCount = $(this).val().length,
      current = $('#current'),
      maximum = $('#maximum'),
      theCount = $('#the-count');
    
  current.text(characterCount);
 
  
  /*This isn't entirely necessary, just playin around*/
  if (characterCount < 70) {
    current.css('color', '#666');
  }
  if (characterCount > 70 && characterCount < 90) {
    current.css('color', '#6d5555');
  }
  if (characterCount > 90 && characterCount < 100) {
    current.css('color', '#793535');
  }
  if (characterCount > 100 && characterCount < 120) {
    current.css('color', '#841c1c');
  }
  if (characterCount > 120 && characterCount < 139) {
    current.css('color', '#8f0001');
  }
  
  if (characterCount >= 140) {
    maximum.css('color', '#8f0001');
    current.css('color', '#8f0001');
    theCount.css('font-weight','bold');
  } else {
    maximum.css('color','#666');
    theCount.css('font-weight','normal');
  }
  
      
});