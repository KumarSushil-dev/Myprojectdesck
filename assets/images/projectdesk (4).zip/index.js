var win=null
var mainController;
var emai="";
var password="";
const userservices = require('./services/user.services')
const imageToBase64 = require('image-to-base64');
const screenshot = require('screenshot-desktop')
const { app, BrowserWindow,ipcMain } = require('electron')
const activeWindow = require('active-win');
const {ipcRenderer} = require('electron')

const Store = require('electron-store');
const store = new Store();
var base64Img = require('base64-img');
 var id =0;
 var timer= 30000;
 const sqlite3 = require('sqlite3').verbose()
 const iohook= require('iohook') 

const { userLogin } = require('./services/user.services');
const dataTransfer= require('./services/datatransfer.service')
 var db = new sqlite3.Database('cachedb');
var screen='demo.jpeg';
async function userLogins (email,password,os){
var ab= await userservices.userLogin(email,password,os);
console.log(email);
console.log(password);
console.log(os);
return ab;
}
async function punchinusers(time,token=store.get("access_token")){
  var res = await userservices.punchIn(time,token)
  return res;
}
async function punchoutusers(time,worktime,token=store.get("access_token")){
  var res = await userservices.punchOut(time,worktime,token)
  return res;
}
 var intervalDuration = 0;
 var count_keydown = 0
 var count_mousemove = 0
 var count_mouseclick = 0
 var appList = []
 var activeSeconds = {
   keyboard: 0,
   mouse: 0,
   system: 0,
 };
 var intervalId = null;
 var detectorIntervalId = null;
 var mouseActiveDuringThisSecond = false;
 var keyboardActiveDuringThisSecond = false;
 var systemActiveDuringThisSecond = true;
 var fromTime = null
 var toTime = null
 var threshold = 15
 var screenshotInterval = 60
 var idleTime = 0
 var tempIdleTime = 0
 var isIdle = false
 var punchedIn = false
 var userID = null
 var screenshotPermission = false
 function start(thr=10, screenInterval=300000) {
  fromTime = Date.now()
  count_keydown = 0
  count_mouseclick = 0
  count_mousemove = 0
  intervalDuration = 0
  activeSeconds.keyboard = 0;
  activeSeconds.mouse = 0;
  activeSeconds.system = 0;
  idleTime = 0;
  tempIdleTime = 1
  isIdle = false
  appList = []
intervalId = setInterval(async  () => {
    console.log("CHECKING INTERVAL ************************************************************ "+intervalDuration, Date.now(),punchedIn)
    intervalDuration += 1;
if (keyboardActiveDuringThisSecond)
      activeSeconds.keyboard += 1;
if (mouseActiveDuringThisSecond)
      activeSeconds.mouse += 1;
if (
      mouseActiveDuringThisSecond
      || keyboardActiveDuringThisSecond
      || systemActiveDuringThisSecond
    ){
      activeSeconds.system += 1;
      tempIdleTime = 0;
      isIdle = false
      console.log("ACTIVITY DETECTED *************** "+intervalDuration + " / counter ** "+activeSeconds.system)
    }else{
      if(!isIdle){
      tempIdleTime += 1;
      console.log("IDLE DETECTED *************** "+intervalDuration + " / counter ** "+tempIdleTime)
      }
    }
    keyboardActiveDuringThisSecond = false;
    mouseActiveDuringThisSecond = false;
    systemActiveDuringThisSecond = false;
    let processes = await activeWindow()
    var appdata={

      windowClass:"",
      windowName:""
      
    }
    if(processes){
      appdata.windowClass= processes.owner.name
      appdata.windowName=processes.title
      
      
      appList.push(appdata)
    }
  if(tempIdleTime==threshold){
      console.log("Idle detected with threshold ** "+tempIdleTime+" **** at "+intervalDuration)
      idleTime += tempIdleTime
      tempIdleTime=0
      isIdle = true
    }else if(isIdle){
      idleTime += 1    
      console.log("Idle detection count "+idleTime+" seconds *** at" + intervalDuration)
    }
}, 1000);
  if (iohook)
    iohook.start();
}
async function stop() {
  if (intervalId)
    clearInterval(intervalId);
    clearInterval(detectorIntervalId);
    fromTime = Date.now()
    intervalId = null;
    keyboardActiveDuringThisSecond = false;
    mouseActiveDuringThisSecond = false;
    activeSeconds.keyboard = 0;
    activeSeconds.mouse = 0;
    activeSeconds.system = 0;
    intervalDuration = 0;
    idleTime = 0;
    tempIdleTime = 1
    isIdle = false
    appList = []
    keyboardActiveDuringThisSecond = false;
    mouseActiveDuringThisSecond = false;
    systemActiveDuringThisSecond = false;
detectorIntervalId = null;
if (iohook)
      iohook.stop();
    }

/**
 * Resets the counters
 */
function reset() {
    // clearInterval(intervalId);
    fromTime = Date.now()
    activeSeconds.keyboard = 0;
    activeSeconds.mouse = 0;
    activeSeconds.system = 0;
    intervalDuration = 0;
    idleTime = 0;
    tempIdleTime = 1
    isIdle = false
    appList = []

    keyboardActiveDuringThisSecond = false;
    mouseActiveDuringThisSecond = false;
    systemActiveDuringThisSecond = false;

    count_keydown = 0
    count_mouseclick = 0
    count_mousemove = 0

}

function systemPercentage() {

  // Avoid Infinity in results
  if (activeSeconds.system === 0)
      return 0;

  return Math.ceil(activeSeconds.system / (intervalDuration / 100));

}


iohook.on('keydown', () => {

  keyboardActiveDuringThisSecond = true;
  count_keydown+=1
  activeSeconds.keyboard+=1
 //console.log("KEYDOWN DETECTED")

});

iohook.on('mousemove', () => {
  
  mouseActiveDuringThisSecond = true;
  
  count_mousemove+=1
  activeSeconds.mouse=+1
 //console.log("MOUSEMOVE DETECTED")
});

iohook.on('mousewheel', () => {

  mouseActiveDuringThisSecond = true;
  activeSeconds.mouse=+1
  count_mousemove+=1
 //console.log("MOUSEwheel DETECTED")
});

iohook.on('mousedown', () => {
  mouseActiveDuringThisSecond = true;
  count_mouseclick+=1  
});

function getEventCount(){
appList= parseapp(appList);
  var  productivity=100
  if (idleTime == 0) {
productivity =100

  }
productivity = ((idleTime*1000)/timer) *100;
productivity = 100- productivity
var productivetime= timer -  idleTime
if (productivity == 0 || productivity==0.0)
productivity=100

  ++id
 
return { intervalDuration, count_keydown, count_mousemove, count_mouseclick, fromTime, activeSeconds, idleTime, screenshotInterval,appList,screen,productivity,productivetime}
}
function createWindow () {
    win = new BrowserWindow({
      width: 570,
      height: 678,
      icon:'icon.png',
      webPreferences: {
        nodeIntegration: true,
        contextIsolation: false,
        enableRemoteModule: true
      },
  

    })

 if( store.get("access_token")){
    win.loadFile('home-screen.html')
   }else{
     win.loadFile('index.html')
   }

   //win.setMenu(null)
   win.hasShadow(false)
  
   win.webContents.closeDevTools()

   win.setMaximizable(false)
   
   }



  app.whenReady().then(() => {
    
    
    // Alternatively, pass true to start in DEBUG mode.
   
    createWindow()
    const gotTheLock = app.requestSingleInstanceLock()
    
    if (!gotTheLock) {
      app.quit()
    } else {
      app.on('second-instance', (event, commandLine, workingDirectory) => {
        // Someone tried to run a second instance, we should focus our window.
        if (win) {
          if (win.isMinimized()) win.restore()
          win.focus()
        }
      })}
    

//start();

ipcMain.on('asynchronous-messagess',async (event,arg)=> {

console.log("Punch in Clicked");
console.log(arg,",,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,");
a =await punchinusers(arg)
//console.log(a)

start()
mainController=      setInterval(()=>{
  screenshot({ filename: 'demo.jpeg' }).then(async (imgPath) => {
     
     base64Img.base64('demo.jpeg', async function(err, data) {
       if(err){
         console.log(err,'ddddddddddddd');

       }
      var datas;
      datas=data
      var stats = await getEventCount()
      console.log(stats.count_keydown)
      save_to_db(id,count_mouseclick,count_mousemove,count_keydown, stats.productivity,stats.idleTime,datas,JSON.stringify( stats.appList),process.platform,Date(),Date(),stats.productivetime)
      
     
    

     
      //var s=await dataTransfer.datatransfer(stats.productivity,datas,stats.idleTime,stats.count_keydown,stats.count_mousemove,stats.count_mouseclick,stats.appList,new Date(),stats.productivetime,store.get('access_token'))  
      //console.log(s);
    
      reset();
     });
    //datas="ssddsdd"
     
     //console.log(data.data);klk
  
  });
 // console.log(getEventCount());
 // reset()
  },timer)
  ipcMain.on('status', async (event, arg)=> {
    console.log(arg,"ssssssssssssssssssssssssss");
     if (arg=='online'){
await send_all_data_to_server()
//ipcRenderer.send('refresh',0)
     }
  }) 

})

ipcMain.on('asynchronous-message', (event, arg) => {
emai=arg  
  event.sender.send('asynchronous-reply', 'kya haal ha' );
  });
ipcMain.on('asynchronous-messages', async (event, arg) => {
password=arg;
     console.log(emai,"---------------------------------");
     console.log(password,"-------------------------------");
     
a = await userLogins(emai,password,process.platform)
console.log(a.data);
if (a.data.success==true) {
  store.set("access_token",a.data.data[0].token);
  store.set('user_name',a.data.name)
console.log(a.data.data[0].token);
win.loadFile('home-screen.html')


}else{
  win.loadFile('index.html')
}
 
      event.sender.send('asynchronous-replys', 'kya haal ha' );
      });




      ipcMain.on('asynchronous-puchout',async  (event, arg)=>{
       console.log(arg);
        var g=  await punchoutusers(arg[0],arg[1])
        
        stop()
        console.log(g.data);
        clearInterval(mainController)


      })

      ipcMain.on('asynchronous-logout',async  (event, arg)=>{
        console.log(arg);
         store.clear()
         win.loadFile('index.html')
         clearInterval(mainController)
        stop(); 
       })




})
const parseapp = (arr) => {
    const res = {};
    arr.forEach((obj) => {
       const key = `${obj.Country}${obj["windowName"]}`;
       if (!res[key]) {
          res[key] = { ...obj, count: 0 };
       };
       res[key].count += 1;
    });
 return Object.values(res);
};
db.serialize(function() {
var createTable_query= "CREATE TABLE IF NOT EXISTS info (id integer PRIMARY KEY,mouseclick INTEGER NOT NULL,mousemove INTEGER NOT NULL,keypress INTEGER NOT NULL,productivity INTEGER NOT NULL,idletime INTEGER NOT NULL,screenshort LONGTEXT NOT NULL,applist TEXT NOT NULL,os TEXT NOT NULL,created TEXT NOT NULL,updated TEXT NOT NULL,productivetime INTEGER NOT NULL);"
  db.run(createTable_query);
});
function save_to_db(id,mouseclick,mousemove,keypress,productivity,idletime,screenshort,applist,os,created,updated,productivetime){
  var stmt = db.prepare("INSERT INTO info (mouseclick,mousemove,keypress,productivity,idletime,screenshort,applist,os,created,updated,productivetime) VALUES (?,?,?,?,?,?,?,?,?,?,?)");
  stmt.run(mouseclick,mousemove,keypress,productivity,idletime,screenshort,applist,os,created,updated,productivetime)
stmt.finalize()
}

function count_rows(){
 db.all(' SELECT  COUNT(*) as total  FROM info;',[],(err,row)=>{
 console.log(row[0].total,"kkkkkkkkkkkkkkkkkkkkkkkkkkkkkkk");
  return row[0].total;



})





}



 async function send_all_data_to_server(){
 
  let sql = `SELECT productivity productivity,
  screenshort screenshort, idletime idletime,
  keypress keypress, mousemove mousemove,productivetime productivetime, 
  mouseclick mouseclick, applist applist , created created
  
FROM info`;



 db.all(sql, [], (err, rows) => {
  if (err) {
    throw err;
  }
   if(rows.length>0){
  rows.forEach(async (row) => {
    console.log(row.mouseclick);
//console.log(row.applist,"       ");
    var s=await dataTransfer.datatransfer(row.productivity,row.screenshort,row.idletime,row.keypress,row.mousemove, row.mouseclick,row.applist,row.created,row.productivetime,store.get('access_token'))  
  console.log(s);
  });
  db.run(' DELETE   FROM info;')
};
 

});

//ipcRenderer.send('refresh',"0" )

//

   }


 
            